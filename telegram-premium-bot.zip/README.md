# Telegram Premium Bot

### Features
- /start shows subscription plans + image + buttons
- Buy Subscription & Pay Per Video flows
- Payment proof handling (forwarded to admin group)
- Admin approve/reject system with inline buttons
- Subscription approval -> group invite link sent
- Pay-per-video -> movie request flow

### How to deploy on Render
1. Push this repo to GitHub
2. Create new Web Service on Render
3. Set environment variables:
   - TELEGRAM_TOKEN
   - ADMIN_GROUP_ID (chat_id of your admin group)
   - GROUP_INVITE_LINK (invite link of your premium group)
   - WEBHOOK_SECRET (any random string)
4. Deploy
5. Set webhook:
```
https://api.telegram.org/bot<YOUR_TOKEN>/setWebhook?url=https://your-app.onrender.com/webhook/<WEBHOOK_SECRET>
```
